"""
Optional LLM-based explanation enhancement. Supports Alibaba Cloud Model
Studio (DashScope) OR Google Gemini (OpenAI-compatible endpoint) -- both
are permitted per the hackathon's re-evaluation email, which explicitly
states participants are "not restricted to a single toolchain" and may use
"your own API keys, connected to the platform of your choice."

CRITICAL design constraint: this NEVER replaces the verified static
explanation from knowledge_base.json as the source of truth. It only tries
to rephrase/personalize it using the value and abnormal status already
computed deterministically elsewhere. If no key is set, the call fails, or
it's slow, this silently falls back to the original static explanation --
the pipeline must never break or hang because of this.

This is also ONLY used for tests already in the verified knowledge base --
never called for unknown tests, and it never has authority to invent new
medical claims. The system prompt explicitly forbids diagnostic language.
"""

import os
from dotenv import load_dotenv

_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # backend/
_ENV_PATH = os.path.join(_BACKEND_DIR, ".env")
load_dotenv(dotenv_path=_ENV_PATH, override=True)

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
DASHSCOPE_API_KEY = os.environ.get("DASHSCOPE_API_KEY")
MODEL_STUDIO_WORKSPACE_ID = os.environ.get("MODEL_STUDIO_WORKSPACE_ID")

# Provider selection: Gemini first if configured (free tier, no billing
# setup needed -- fastest to get working), otherwise Alibaba Model Studio
# if that's configured, otherwise disabled (static explanations only).
if GEMINI_API_KEY:
    PROVIDER = "gemini"
    API_KEY = GEMINI_API_KEY
    BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"
    MODEL_NAME = os.environ.get("LLM_MODEL", "gemini-2.5-flash")
elif DASHSCOPE_API_KEY:
    PROVIDER = "alibaba_model_studio"
    API_KEY = DASHSCOPE_API_KEY
    if MODEL_STUDIO_WORKSPACE_ID:
        BASE_URL = f"https://{MODEL_STUDIO_WORKSPACE_ID}.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1"
    else:
        BASE_URL = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
    MODEL_NAME = os.environ.get("LLM_MODEL", "qwen3.7-plus")
else:
    PROVIDER = None
    API_KEY = None
    BASE_URL = None
    MODEL_NAME = None

ENABLED = PROVIDER is not None

if ENABLED:
    print(f"[llm_generation.py] Using provider: {PROVIDER}, model: {MODEL_NAME} — LLM enhancement active.")
else:
    print("[llm_generation.py] No GEMINI_API_KEY or DASHSCOPE_API_KEY set — using static explanations only (this is safe and expected if you haven't set this up yet).")

SYSTEM_PROMPT = """You rephrase an already-written, medically-verified explanation of a lab test result to sound more natural and personalized, in both English and Urdu.

STRICT RULES:
- Do NOT add any medical claim, cause, or fact that is not already present in the source explanation given to you.
- Do NOT diagnose. Never say the patient "has" a condition or disease.
- Keep the same core meaning as the source explanation -- you are rephrasing, not adding new information.
- Keep it concise: 2-3 sentences per language.
- Output ONLY valid JSON with exactly two keys: "explanation_en" and "explanation_ur". No other text."""


def enhance_explanation(test_name: str, value: str, abnormal_status: str, static_explanation_en: str, static_explanation_ur: str, timeout_seconds: float = 20.0):
    """
    Returns (explanation_en, explanation_ur) -- either LLM-enhanced or, on
    ANY failure/timeout/disabled state, the original static text unchanged.
    Never raises.
    """
    if not ENABLED:
        return static_explanation_en, static_explanation_ur

    try:
        from openai import OpenAI

        client = OpenAI(api_key=API_KEY, base_url=BASE_URL, timeout=timeout_seconds)

        user_prompt = f"""Test: {test_name}
Patient's value: {value if value else "(not provided)"}
Status: {abnormal_status if abnormal_status else "(not evaluated)"}
Source explanation (English): {static_explanation_en}
Source explanation (Urdu): {static_explanation_ur}

Rephrase both, personalized to this value if provided. Respond with JSON only."""

        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            timeout=timeout_seconds,
        )

        import json
        content = response.choices[0].message.content.strip()
        if content.startswith("```"):
            content = content.strip("`")
            if content.startswith("json"):
                content = content[4:].strip()
        parsed = json.loads(content)

        new_en = parsed.get("explanation_en", "").strip()
        new_ur = parsed.get("explanation_ur", "").strip()

        if len(new_en) < 10 or len(new_ur) < 10:
            return static_explanation_en, static_explanation_ur

        return new_en, new_ur

    except Exception as e:
        print(f"[llm_generation.py] Enhancement failed ({e}); using static explanation.")
        return static_explanation_en, static_explanation_ur
