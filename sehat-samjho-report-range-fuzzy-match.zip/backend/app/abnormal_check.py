"""
Deterministic abnormal-value flagging. Deliberately NOT an LLM call — parsing
a number and comparing it to a range is a good fit for simple rules, and
keeping this deterministic means flagging is 100% reproducible and testable.

Reference ranges in knowledge_base.json are free-text (e.g. "13.5-17.5
(male), 12.0-15.5 (female)", "under 140", "0.4-4.0"). This module parses the
common patterns. When a range can't be confidently parsed (e.g. multi-tier
ranges like HbA1c's), it returns "range_unclear" rather than guessing --
consistent with the project's no-guessing safety principle.
"""

import re

SIMPLE_RANGE = re.compile(r"^(\d+\.?\d*)\s*-\s*(\d+\.?\d*)$")
UNDER_PATTERN = re.compile(r"^under\s+(\d+\.?\d*)$", re.IGNORECASE)
OVER_PATTERN = re.compile(r"^over\s+(\d+\.?\d*)$", re.IGNORECASE)
GENDER_SPLIT = re.compile(
    r"(\d+\.?\d*)\s*-\s*(\d+\.?\d*)\s*\(male\).*?(\d+\.?\d*)\s*-\s*(\d+\.?\d*)\s*\(female\)",
    re.IGNORECASE,
)
# Common real-world report notation: "M: 14-18, F: 11.5-16.5" (no
# parentheses, letter-colon prefix instead)
GENDER_SPLIT_COLON = re.compile(
    r"M\s*:\s*(\d+\.?\d*)\s*-\s*(\d+\.?\d*).*?F\s*:\s*(\d+\.?\d*)\s*-\s*(\d+\.?\d*)",
    re.IGNORECASE,
)
GENDER_OVER_SPLIT = re.compile(
    r"over\s+(\d+\.?\d*)\s*\(male\).*?over\s+(\d+\.?\d*)\s*\(female\)",
    re.IGNORECASE,
)


def _strip_trailing_note(range_text: str) -> str:
    """Removes a single trailing parenthetical note like '(desirable)' or
    '(normal)' that isn't a male/female split, so SIMPLE_RANGE can match."""
    if "male" in range_text.lower() or "female" in range_text.lower():
        return range_text
    return re.sub(r"\s*\([^)]*\)\s*$", "", range_text).strip()


def parse_bounds(reference_range: str):
    """
    Returns (low, high) as floats, where either may be None (open-ended),
    or None if the range could not be confidently parsed.

    For gender-split ranges, returns the COMBINED (wider) bound -- since we
    don't collect the user's gender in the MVP, we deliberately use the
    union of both ranges to avoid false-positive abnormal flags. This is a
    conservative choice: it may miss some abnormal values, but it will
    never wrongly flag a normal value as abnormal due to a gender mismatch.
    """
    text = reference_range.strip()

    gender_match = GENDER_SPLIT.search(text)
    if gender_match:
        lows = [float(gender_match.group(1)), float(gender_match.group(3))]
        highs = [float(gender_match.group(2)), float(gender_match.group(4))]
        return (min(lows), max(highs))

    gender_colon_match = GENDER_SPLIT_COLON.search(text)
    if gender_colon_match:
        lows = [float(gender_colon_match.group(1)), float(gender_colon_match.group(3))]
        highs = [float(gender_colon_match.group(2)), float(gender_colon_match.group(4))]
        return (min(lows), max(highs))

    gender_over_match = GENDER_OVER_SPLIT.search(text)
    if gender_over_match:
        lows = [float(gender_over_match.group(1)), float(gender_over_match.group(2))]
        return (min(lows), None)

    clean = _strip_trailing_note(text)
    simple_match = SIMPLE_RANGE.match(clean)
    if simple_match:
        return (float(simple_match.group(1)), float(simple_match.group(2)))

    under_match = UNDER_PATTERN.match(clean)
    if under_match:
        return (None, float(under_match.group(1)))

    over_match = OVER_PATTERN.match(clean)
    if over_match:
        return (float(over_match.group(1)), None)

    return None  # range_unclear -- e.g. multi-tier ranges like HbA1c


def check_abnormal(value: str, reference_range: str):
    """
    Main entry point. Returns one of: "normal", "abnormal_low",
    "abnormal_high", "range_unclear", or "value_unparseable".
    Never raises -- always returns a safe, explicit status.
    """
    try:
        numeric_value = float(str(value).strip())
    except (ValueError, TypeError):
        return "value_unparseable"

    bounds = parse_bounds(reference_range)
    if bounds is None:
        return "range_unclear"

    low, high = bounds
    if low is not None and numeric_value < low:
        return "abnormal_low"
    if high is not None and numeric_value > high:
        return "abnormal_high"
    return "normal"
