"""
Component 3 (Data Validation) + Component 4 (Knowledge Retrieval) as a
reusable module, so both the CLI test scripts and the FastAPI app share
the exact same validation/retrieval logic (no duplicated, drifting copies).
"""

import os

# Bug fix: ChromaDB re-verifies the embedding model against Hugging Face on
# every collection load, even though the model is already cached locally
# after the first download. If the network hiccups at that moment (DNS
# failure, flaky connection), this crashes the whole request. Forcing
# offline mode makes it use the cached model directly — no network needed
# once the model has been downloaded once (which it already has).
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

import json
import chromadb

try:
    from chromadb.utils import embedding_functions
    EMBED_FN = embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name="all-MiniLM-L6-v2"
    )
except Exception:
    EMBED_FN = None

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "knowledge_base.json")
DB_PATH = os.path.join(BASE_DIR, "data", "chroma_store")

from app.abnormal_check import check_abnormal
from app.doctor_questions import get_doctor_questions
from app.llm_generation import enhance_explanation

_alias_index = None
_collection = None

def _load_alias_index():
    global _alias_index
    if _alias_index is not None:
        return _alias_index
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        tests = json.load(f)
    index = {}
    for t in tests:
        canonical = t["test_name"]
        index[canonical.strip().lower()] = canonical
        if "(" in canonical and ")" in canonical:
            short_name = canonical.split("(")[0].strip()
            abbreviation = canonical.split("(")[1].replace(")", "").strip()
            index[short_name.lower()] = canonical
            index[abbreviation.lower()] = canonical
        # Optional extra aliases for common lab-report shorthand (e.g. "S."
        # for serum) -- only added where the underlying test is genuinely
        # the same measurement with the same reference range. NOT used for
        # tests that only sound similar but differ clinically (e.g. "Blood
        # Urea" vs "BUN" have different reference ranges and are
        # deliberately NOT aliased together).
        for extra_alias in t.get("aliases", []):
            index[extra_alias.strip().lower()] = canonical
    _alias_index = index
    return _alias_index

def _get_collection():
    global _collection
    if _collection is not None:
        return _collection
    client = chromadb.PersistentClient(path=DB_PATH)
    _collection = client.get_collection(
        name="lab_tests", embedding_function=EMBED_FN
    ) if EMBED_FN else client.get_collection(name="lab_tests")
    return _collection

def is_known_test(test_name: str) -> bool:
    return lookup_canonical(test_name) is not None


def _load_category_index():
    """Returns canonical test_name -> category, so callers can group test
    names into panels (Hematology / Bio-Chemistry / etc.) for display."""
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        tests = json.load(f)
    return {t["test_name"]: t["category"] for t in tests}

def lookup_canonical(test_name: str):
    """
    Returns the canonical test_name if known, else None.
    Two-pass matching:
    1. Exact match against the alias index (fast, precise)
    2. Substring fallback: if a known alias (5+ chars, to avoid false
       positives from short ones) appears anywhere in the normalized input,
       treat it as a match. This handles real-world variants like
       "HEMOGLOBIN %Y" (contains "hemoglobin") that an exact match misses,
       without needing to hand-maintain every possible suffix/notation.
    """
    import re as _re

    def normalize(s: str) -> str:
        return _re.sub(r"[^a-z0-9]", "", s.lower())

    index = _load_alias_index()
    exact = index.get(test_name.strip().lower())
    if exact:
        return exact

    normalized_input = normalize(test_name)
    if not normalized_input:
        return None

    for alias, canonical in index.items():
        normalized_alias = normalize(alias)
        if len(normalized_alias) >= 4 and normalized_alias in normalized_input:
            return canonical

    return None

def get_test_info(test_name: str, value: str = None, normal_range: str = None):
    """
    Main entry point for Component 3 + 4 combined.
    Returns dict with retrieved info if known, or a 'not_supported' response
    if unknown -- this function NEVER calls the LLM for unknown tests.
    If a value is provided, also returns a deterministic abnormal-value
    status (never LLM-guessed).

    For UNKNOWN tests: if the report itself printed a reference range next
    to the value (normal_range), we can still give a transparent numeric
    comparison -- clearly labeled as sourced from the report, not our
    verified database, and WITHOUT any explanation text (we have none to
    verify). This is intentionally a lesser claim than a fully "supported"
    result.
    """
    canonical = lookup_canonical(test_name)
    if not canonical:
        result = {
            "supported": False,
            "test_name": test_name,
            "message": "This test is not yet supported. No guessing — please consult a healthcare professional about this result.",
        }
        if value and normal_range:
            status = check_abnormal(value, normal_range)
            if status in ("normal", "abnormal_low", "abnormal_high"):
                result["report_based_comparison"] = {
                    "value": value,
                    "reference_range": normal_range,
                    "status": status,
                }
        return result

    collection = _get_collection()
    results = collection.query(query_texts=[canonical], n_results=1)
    meta = results["metadatas"][0][0]

    abnormal_status = check_abnormal(value, meta["reference_range"]) if value else None
    doctor_questions = get_doctor_questions(meta["category"], abnormal_status)

    explanation_en, explanation_ur = enhance_explanation(
        test_name=meta["test_name"],
        value=value,
        abnormal_status=abnormal_status,
        static_explanation_en=meta["explanation_en"],
        static_explanation_ur=meta["explanation_ur"],
    )

    return {
        "supported": True,
        "test_name": meta["test_name"],
        "category": meta["category"],
        "unit": meta["unit"],
        "reference_range": meta["reference_range"],
        "explanation_en": explanation_en,
        "explanation_ur": explanation_ur,
        "value": value,
        "abnormal_status": abnormal_status,
        "doctor_questions": doctor_questions,
    }
