"""
Parses raw OCR text (Component 2 output) into structured entries:
{test_name, raw_value, unit}. This is intentionally a simple, transparent
regex-based parser rather than an LLM call — parsing structure from text is
a good fit for deterministic rules, and keeping the LLM out of this step
reduces hallucination risk.

Expected line format (matches common lab report layouts):
    Test Name       123.4   unit   (reference range)

This is a best-effort parser. Whatever it extracts is ALWAYS shown to the
user for manual confirmation/edit before analysis (Component 3) — so a
missed or misparsed line is a UX inconvenience, never a silent safety issue.
"""

import re

# Matches: <name>  <number>  <unit>  (anything else, ignored)
# NOTE: uses \s+ (one or more spaces) rather than \s{2,} -- real OCR output
# (verified with Tesseract) often normalizes multi-space table padding down
# to single spaces, so requiring 2+ spaces was silently dropping valid
# lines. This was caught during Day 7 testing.
LINE_PATTERN = re.compile(
    r"^(?P<name>[A-Za-z][A-Za-z()\s/]+?)\s+"
    r"(?P<value>-?\d+\.?\d*)\s+"
    r"(?P<unit>[A-Za-z%/]+)"
)


def parse_report_text(raw_text: str):
    """
    Returns a list of dicts: [{"test_name": ..., "value": ..., "unit": ...}, ...]
    Lines that don't match the expected pattern are skipped (not guessed at).
    """
    entries = []
    for line in raw_text.splitlines():
        line = line.strip()
        if not line:
            continue
        match = LINE_PATTERN.match(line)
        if not match:
            continue
        if not match.group("name").strip() or not match.group("value").strip():
            continue
        entries.append({
            "test_name": match.group("name").strip(),
            "value": match.group("value").strip(),
            "unit": match.group("unit").strip(),
        })
    return entries


def find_known_test_names(raw_text: str, known_aliases: dict):
    """
    Fallback for real-world reports where the strict name+value+unit pattern
    fails (common cause: handwritten values, or multi-column table layouts
    that confuse line-based parsing -- confirmed against a real report photo
    during Day 7 testing). Printed test NAMES are usually still readable
    even when the handwritten result and table layout are not.

    Scans raw_text for any occurrence of a known test name/alias and
    returns pre-filled rows with an EMPTY value -- so the user only needs
    to type the number, not retype the whole test name. This never guesses
    a value; it only recognizes a name that is genuinely, deterministically
    present in the OCR text (a substring match against the verified alias
    list, punctuation-normalized -- e.g. OCR's "S.G.P.T" still matches the
    "SGPT" alias), which is a materially different and safer claim.

    known_aliases: the alias index dict from knowledge._load_alias_index()
    (alias string -> canonical test_name).
    """
    def normalize(s: str) -> str:
        return re.sub(r"[^a-z0-9]", "", s.lower())

    text_normalized = normalize(raw_text)
    found_canonical = set()
    for alias, canonical in known_aliases.items():
        alias_normalized = normalize(alias)
        if len(alias_normalized) < 3:
            continue  # skip very short aliases (too many false substring hits)
        if alias_normalized in text_normalized:
            found_canonical.add(canonical)

    return [{"test_name": name, "value": "", "unit": ""} for name in sorted(found_canonical)]
