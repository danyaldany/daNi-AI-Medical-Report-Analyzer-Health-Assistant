"use client";

import { useState } from "react";

type ExtractedTest = {
  test_name: string;
  value: string;
  unit: string;
  category?: string;
  normal_range?: string;
};

type ReportBasedComparison = {
  value: string;
  reference_range: string;
  status: string;
};

type TestResult = {
  supported: boolean;
  test_name: string;
  category?: string;
  unit?: string;
  reference_range?: string;
  explanation_en?: string;
  explanation_ur?: string;
  message?: string;
  value?: string;
  abnormal_status?: string;
  doctor_questions?: string[];
  report_based_comparison?: ReportBasedComparison;
};

type MedicineResult = {
  supported: boolean;
  medicine_name?: string;
  message?: string;
  generic_name?: string;
  common_brands_pk?: string[];
  category?: string;
  purpose_en?: string;
  purpose_ur?: string;
  general_notes_en?: string;
  general_notes_ur?: string;
};

const API_BASE = "http://127.0.0.1:8000";

type Suggestion = { test_name: string; category: string };

// Maps our internal, verified test categories to the panel labels
// Pakistani lab reports commonly use. Only tests we've actually verified
// get grouped here -- anything outside our knowledge base stays out of
// this mapping rather than being force-fit into a panel we can't back up.
const PANEL_MAP: Record<string, string> = {
  CBC: "Hematology",
  "Blood Sugar": "Bio-Chemistry",
  "Lipid Profile": "Bio-Chemistry",
  "Liver Function": "Bio-Chemistry",
  "Kidney Function": "Bio-Chemistry",
  Thyroid: "Other Tests",
  Vitamins: "Other Tests",
};

function panelFor(category?: string) {
  if (!category) return "Other Tests";
  return PANEL_MAP[category] || "Other Tests";
}

function groupByPanel<T>(items: T[], getCategory: (item: T) => string | undefined) {
  const groups: Record<string, T[]> = {};
  for (const item of items) {
    const panel = panelFor(getCategory(item));
    if (!groups[panel]) groups[panel] = [];
    groups[panel].push(item);
  }
  // Fixed display order, only including panels that actually have items
  const order = ["Hematology", "Bio-Chemistry", "Other Tests"];
  return order.filter((p) => groups[p]?.length).map((p) => [p, groups[p]] as const);
}

function statusBarClass(status?: string) {
  if (status === "normal") return "status-bar status-bar--normal";
  if (status === "abnormal_low" || status === "abnormal_high")
    return "status-bar status-bar--abnormal";
  if (status === "range_unclear" || status === "value_unparseable")
    return "status-bar status-bar--unclear";
  return "status-bar";
}

function statusLabel(status?: string) {
  if (status === "normal") return { text: "Within range", color: "var(--normal)" };
  if (status === "abnormal_low" || status === "abnormal_high")
    return { text: "Outside reference range", color: "var(--abnormal)" };
  if (status === "range_unclear")
    return { text: "Compare manually with range above", color: "var(--unclear)" };
  if (status === "value_unparseable")
    return { text: "Value format not recognized", color: "var(--unclear)" };
  return null;
}

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [extracted, setExtracted] = useState<ExtractedTest[]>([]);
  const [rawText, setRawText] = useState<string>("");
  const [hasExtractedOnce, setHasExtractedOnce] = useState(false);
  const [results, setResults] = useState<TestResult[] | null>(null);
  const [medicines, setMedicines] = useState<string[]>([]);
  const [medicineResults, setMedicineResults] = useState<MedicineResult[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleUpload() {
    if (!file) return;
    setLoading(true);
    setError(null);
    setResults(null);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch(`${API_BASE}/ocr/extract`, {
        method: "POST",
        body: formData,
      });
      if (!res.ok) throw new Error(`OCR request failed (${res.status})`);
      const data = await res.json();
      const strictEntries: ExtractedTest[] = data.extracted_tests || [];
      const suggestions: Suggestion[] = data.suggested_test_names || [];

      // Merge suggestions directly into the table (empty value) instead of
      // requiring a click per suggestion — the user just fills in numbers
      // for rows that are already there.
      const alreadyNamed = new Set(strictEntries.map((e) => e.test_name.toLowerCase()));
      const merged: ExtractedTest[] = [
        ...strictEntries,
        ...suggestions
          .filter((s) => !alreadyNamed.has(s.test_name.toLowerCase()))
          .map((s) => ({ test_name: s.test_name, value: "", unit: "", category: s.category })),
      ];

      setExtracted(merged);
      setRawText(data.raw_text || "");
      setHasExtractedOnce(true);
    } catch (e: any) {
      setError(e.message || "Something went wrong during upload.");
    } finally {
      setLoading(false);
    }
  }

  function updateField(index: number, field: keyof ExtractedTest, value: string) {
    setExtracted((prev) =>
      prev.map((row, i) => (i === index ? { ...row, [field]: value } : row))
    );
  }

  function removeRow(index: number) {
    setExtracted((prev) => prev.filter((_, i) => i !== index));
  }

  function addRow() {
    setExtracted((prev) => [...prev, { test_name: "", value: "", unit: "" }]);
  }

  function updateMedicine(index: number, value: string) {
    setMedicines((prev) => prev.map((m, i) => (i === index ? value : m)));
  }

  function addMedicineRow() {
    setMedicines((prev) => [...prev, ""]);
  }

  function removeMedicineRow(index: number) {
    setMedicines((prev) => prev.filter((_, i) => i !== index));
  }

  function startOver() {
    setFile(null);
    setExtracted([]);
    setRawText("");
    setHasExtractedOnce(false);
    setResults(null);
    setMedicines([]);
    setMedicineResults(null);
    setError(null);
  }

  async function handleConfirmAndAnalyze() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`${API_BASE}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tests: extracted
            .filter((e) => e.test_name.trim() !== "")
            .map((e) => ({ test_name: e.test_name, value: e.value, normal_range: e.normal_range })),
          medicines: medicines.filter((m) => m.trim() !== ""),
        }),
      });
      if (!res.ok) throw new Error(`Analyze request failed (${res.status})`);
      const data = await res.json();
      setResults(data.tests || []);
      setMedicineResults(data.medicines || []);
    } catch (e: any) {
      setError(e.message || "Something went wrong during analysis.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="max-w-2xl mx-auto px-6 py-10 space-y-8">
      {/* Header */}
      <header className="space-y-2 pb-6" style={{ borderBottom: "1px solid var(--hairline)" }}>
        <div className="flex items-baseline gap-2">
          <span
            className="inline-block w-2 h-2 rounded-full"
            style={{ background: "var(--teal)" }}
            aria-hidden="true"
          />
          <h1 className="font-display text-2xl" style={{ color: "var(--ink)" }}>
            Sehat Samjho
          </h1>
        </div>
        <p className="text-sm" style={{ color: "var(--ink-soft)" }}>
          Upload a lab report to get a plain-language, bilingual explanation.
          Extracted values are always shown for your review before analysis —
          nothing is assumed on your behalf.
        </p>
      </header>

      {/* Step 1: Upload */}
      {!hasExtractedOnce && (
        <section
          className="p-5 space-y-3"
          style={{ border: "1px solid var(--hairline)", borderRadius: "4px" }}
        >
          <label className="block text-sm font-medium" style={{ color: "var(--ink)" }}>
            Report image or PDF
          </label>
          <input
            type="file"
            accept="image/*,.pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="text-sm"
          />
          <div>
            <button
              onClick={handleUpload}
              disabled={!file || loading}
              className="px-4 py-2 text-sm font-medium text-white disabled:opacity-40"
              style={{ background: "var(--teal)", borderRadius: "4px" }}
            >
              {loading ? "Reading report…" : "Extract report data"}
            </button>
          </div>
        </section>
      )}

      {error && (
        <p className="text-sm" style={{ color: "var(--abnormal)" }}>
          {error}
        </p>
      )}

      {/* Step 2: Mandatory manual review */}
      {hasExtractedOnce && (
        <section
          className="p-5 space-y-4"
          style={{ border: "1px solid var(--hairline)", borderRadius: "4px" }}
        >
          <div>
            <h2 className="font-medium" style={{ color: "var(--ink)" }}>
              Confirm your report's values
            </h2>
            <p className="text-xs mt-0.5" style={{ color: "var(--ink-soft)" }}>
              Please review what was read from your report before we look anything up.
            </p>
          </div>

          {extracted.length === 0 && (
            <p className="text-sm" style={{ color: "var(--unclear)" }}>
              No test values were automatically read from this report.
              Add them manually below, or check the raw text to see what was read.
            </p>
          )}

          {extracted.length > 0 && (
            <div className="space-y-4">
              {groupByPanel(
                extracted.map((row, i) => ({ ...row, _index: i })),
                (row) => row.category
              ).map(([panel, rows]) => (
                <div key={panel}>
                  <p
                    className="text-xs font-medium mb-1"
                    style={{ color: "var(--teal)" }}
                  >
                    🔬 {panel}
                  </p>
                  <table className="w-full text-sm tabular">
                    <thead>
                      <tr
                        className="text-left"
                        style={{ borderBottom: "1px solid var(--hairline)", color: "var(--ink-soft)" }}
                      >
                        <th className="py-1.5 font-medium">Test name</th>
                        <th className="font-medium">Value</th>
                        <th className="font-medium">Unit</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((row) => (
                        <tr key={row._index} style={{ borderBottom: "1px solid var(--hairline-soft)" }}>
                          <td className="py-1.5">
                            <input
                              className="px-1.5 py-1 w-full bg-transparent"
                              style={{ border: "1px solid var(--hairline)", borderRadius: "3px" }}
                              value={row.test_name}
                              onChange={(e) => updateField(row._index, "test_name", e.target.value)}
                            />
                          </td>
                          <td>
                            <input
                              className="px-1.5 py-1 w-20 bg-transparent"
                              style={{ border: "1px solid var(--hairline)", borderRadius: "3px" }}
                              placeholder="N/A"
                              value={row.value}
                              onChange={(e) => updateField(row._index, "value", e.target.value)}
                            />
                          </td>
                          <td>
                            <input
                              className="px-1.5 py-1 w-20 bg-transparent"
                              style={{ border: "1px solid var(--hairline)", borderRadius: "3px" }}
                              value={row.unit}
                              onChange={(e) => updateField(row._index, "unit", e.target.value)}
                            />
                          </td>
                          <td className="text-right">
                            <button
                              onClick={() => removeRow(row._index)}
                              className="text-xs"
                              style={{ color: "var(--ink-soft)" }}
                            >
                              Remove
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}
              <p className="text-xs" style={{ color: "var(--ink-soft)" }}>
                Rows with no value shown will be skipped in the analysis —
                fill in a number only where you actually have a result.
              </p>
            </div>
          )}

          <button onClick={addRow} className="text-sm" style={{ color: "var(--teal)" }}>
            + Add a test manually
          </button>

          {/* Medicines — independent component */}
          <div className="pt-3" style={{ borderTop: "1px solid var(--hairline)" }}>
            <h3 className="text-sm font-medium mb-2" style={{ color: "var(--ink)" }}>
              Medicines mentioned on this report{" "}
              <span className="font-normal" style={{ color: "var(--ink-soft)" }}>
                (optional)
              </span>
            </h3>
            {medicines.map((m, i) => (
              <div key={i} className="flex gap-2 mb-1.5">
                <input
                  className="px-2 py-1 text-sm flex-1 bg-transparent"
                  style={{ border: "1px solid var(--hairline)", borderRadius: "3px" }}
                  placeholder="e.g. Panadol"
                  value={m}
                  onChange={(e) => updateMedicine(i, e.target.value)}
                />
                <button
                  onClick={() => removeMedicineRow(i)}
                  className="text-xs"
                  style={{ color: "var(--ink-soft)" }}
                >
                  Remove
                </button>
              </div>
            ))}
            <button
              onClick={addMedicineRow}
              className="text-sm"
              style={{ color: "var(--teal)" }}
            >
              + Add a medicine
            </button>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleConfirmAndAnalyze}
              disabled={loading || (extracted.length === 0 && medicines.length === 0)}
              className="px-4 py-2 text-sm font-medium text-white disabled:opacity-40"
              style={{ background: "var(--teal)", borderRadius: "4px" }}
            >
              {loading ? "Analyzing…" : "Confirm and analyze"}
            </button>
            <button onClick={startOver} className="text-sm" style={{ color: "var(--ink-soft)" }}>
              Start over
            </button>
          </div>

          {rawText && (
            <details className="text-xs" style={{ color: "var(--ink-soft)" }}>
              <summary className="cursor-pointer">Show raw OCR text (debug)</summary>
              <pre
                className="whitespace-pre-wrap p-2 mt-1"
                style={{ background: "var(--hairline-soft)", borderRadius: "3px" }}
              >
                {rawText}
              </pre>
            </details>
          )}
        </section>
      )}

      {/* Step 3: Results */}
      {results && (
        <section className="space-y-4">
          <h2 className="font-display text-lg" style={{ color: "var(--ink)" }}>
            Results
          </h2>

          {(() => {
            const supportedResults = results.filter((r) => r.supported && r.abnormal_status);
            const allNormal =
              supportedResults.length > 0 &&
              supportedResults.every((r) => r.abnormal_status === "normal");
            if (!allNormal) return null;
            return (
              <p
                className="status-bar status-bar--normal pl-4 py-2 text-sm font-medium"
                style={{ background: "white", color: "var(--normal)" }}
              >
                All {supportedResults.length} recognized result
                {supportedResults.length > 1 ? "s are" : " is"} within the normal
                reference range.
              </p>
            );
          })()}

          {(() => {
            const supported = results.filter((r) => r.supported);
            const unsupported = results.filter((r) => !r.supported);

            function renderCard(r: TestResult, key: number) {
              const label = r.supported ? statusLabel(r.abnormal_status) : null;
              return (
                <div
                  key={key}
                  className={`${statusBarClass(r.abnormal_status)} pl-4 py-3`}
                  style={{ background: "white" }}
                >
                  <p className="font-medium" style={{ color: "var(--ink)" }}>
                    {r.test_name}
                  </p>
                  {r.supported ? (
                    <>
                      <p className="text-xs mt-0.5" style={{ color: "var(--ink-soft)" }}>
                        Reference range: {r.reference_range} {r.unit}
                      </p>
                      {r.value && label && (
                        <p className="text-sm font-medium mt-1 tabular">
                          Your value: {r.value} {r.unit} —{" "}
                          <span style={{ color: label.color }}>{label.text}</span>
                        </p>
                      )}
                      <p className="text-sm mt-2 leading-relaxed" style={{ color: "var(--ink)" }}>
                        {r.explanation_en}
                      </p>
                      <p className="font-urdu text-sm mt-2" dir="rtl" style={{ color: "var(--ink)" }}>
                        {r.explanation_ur}
                      </p>
                      {r.doctor_questions && r.doctor_questions.length > 0 && (
                        <div className="mt-3 pt-2" style={{ borderTop: "1px solid var(--hairline-soft)" }}>
                          <p className="text-xs font-medium" style={{ color: "var(--ink-soft)" }}>
                            Questions to ask your doctor
                          </p>
                          <ul className="text-xs mt-1 space-y-0.5" style={{ color: "var(--ink-soft)" }}>
                            {r.doctor_questions.map((q, qi) => (
                              <li key={qi}>— {q}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      <p className="text-sm mt-1" style={{ color: "var(--unclear)" }}>
                        {r.message}
                      </p>
                      {r.report_based_comparison && (
                        <div
                          className="mt-2 p-2 text-xs"
                          style={{ background: "var(--hairline-soft)", borderRadius: "3px" }}
                        >
                          <p className="tabular font-medium" style={{ color: "var(--ink)" }}>
                            Your value: {r.report_based_comparison.value} — range on your
                            report: {r.report_based_comparison.reference_range} —{" "}
                            {r.report_based_comparison.status === "normal" ? (
                              <span style={{ color: "var(--normal)" }}>within range</span>
                            ) : (
                              <span style={{ color: "var(--abnormal)" }}>outside range</span>
                            )}
                          </p>
                          <p className="mt-1 italic" style={{ color: "var(--ink-soft)" }}>
                            This comparison uses the range printed on your
                            own report — it is not independently verified
                            by us, unlike the tests above.
                          </p>
                        </div>
                      )}
                    </>
                  )}
                </div>
              );
            }

            return (
              <>
                {groupByPanel(supported, (r) => r.category).map(([panel, items]) => (
                  <div key={panel} className="space-y-3">
                    <p
                      className="text-xs font-medium uppercase tracking-wide"
                      style={{ color: "var(--teal)" }}
                    >
                      🔬 {panel}
                    </p>
                    {items.map((r, i) => renderCard(r, i))}
                  </div>
                ))}

                {unsupported.length > 0 && (
                  <div className="space-y-3">
                    <p
                      className="text-xs font-medium uppercase tracking-wide"
                      style={{ color: "var(--ink-soft)" }}
                    >
                      Not in our verified database
                    </p>
                    <p className="text-xs" style={{ color: "var(--ink-soft)" }}>
                      These tests were included, but we don't have verified
                      reference data for them yet — no status is shown for
                      these, by design, rather than guessing.
                    </p>
                    {unsupported.map((r, i) => renderCard(r, i))}
                  </div>
                )}
              </>
            );
          })()}

          {medicineResults && medicineResults.length > 0 && (
            <div className="pt-2 space-y-3">
              <h3 className="text-sm font-medium" style={{ color: "var(--ink-soft)" }}>
                Medicines
              </h3>
              {medicineResults.map((m, i) => (
                <div
                  key={i}
                  className="status-bar pl-4 py-3"
                  style={{ background: "white" }}
                >
                  <p className="font-medium" style={{ color: "var(--ink)" }}>
                    {m.medicine_name || m.generic_name}
                  </p>
                  {m.supported ? (
                    <>
                      {m.common_brands_pk && m.common_brands_pk.length > 0 && (
                        <p className="text-xs" style={{ color: "var(--ink-soft)" }}>
                          Common brands in Pakistan: {m.common_brands_pk.join(", ")}
                        </p>
                      )}
                      <p className="text-xs" style={{ color: "var(--ink-soft)" }}>
                        {m.category}
                      </p>
                      <p className="text-sm mt-1" style={{ color: "var(--ink)" }}>
                        {m.purpose_en}
                      </p>
                      <p className="font-urdu text-sm mt-1" dir="rtl" style={{ color: "var(--ink)" }}>
                        {m.purpose_ur}
                      </p>
                      <p className="text-xs mt-1" style={{ color: "var(--ink-soft)" }}>
                        {m.general_notes_en}
                      </p>
                      <p className="font-urdu text-xs mt-1" dir="rtl" style={{ color: "var(--ink-soft)" }}>
                        {m.general_notes_ur}
                      </p>
                    </>
                  ) : (
                    <p className="text-sm mt-1" style={{ color: "var(--unclear)" }}>
                      {m.message}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}

          <p className="text-xs italic pt-2" style={{ color: "var(--ink-soft)" }}>
            This is not a substitute for professional medical advice. Please
            consult a doctor about your results.
          </p>
        </section>
      )}
    </main>
  );
}
